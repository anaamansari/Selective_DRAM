export OPENHMC_PATH=`pwd`
export OPENHMC_SIM=`pwd`/sim
