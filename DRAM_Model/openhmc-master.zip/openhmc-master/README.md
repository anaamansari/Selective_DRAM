openhmc
=======

openHMC - an open source Hybrid Memory Cube Controller

Website:
http://ra.ziti.uni-heidelberg.de/openhmc

Contact:
openhmc@ziti.uni-heidelberg.de

openHMC on LinkedIn:
http://www.linkedin.com/groups/openHMC-8178454
